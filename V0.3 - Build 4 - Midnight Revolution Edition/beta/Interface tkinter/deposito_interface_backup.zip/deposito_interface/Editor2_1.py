import tkinter as tk
from tkinter import filedialog
import ast

# =========================
# JANELA
# =========================

root = tk.Tk()
root.title("Horizon Editor")
root.geometry("1000x600")
root.configure(bg="#1e1e1e")

arquivo_atual = None

# =========================
# FUNÇÕES
# =========================

def adicionar_log(msg):
    painel.config(state="normal")
    painel.insert(tk.END, msg + "\n")
    painel.see(tk.END)
    painel.config(state="disabled")


def novo_arquivo():
    global arquivo_atual

    arquivo_atual = None
    editor.delete("1.0", tk.END)

    status.config(text="Novo arquivo")
    adicionar_log("📄 Novo arquivo criado")


def abrir_arquivo():
    global arquivo_atual

    caminho = filedialog.askopenfilename(
        filetypes=[("Python", "*.py"), ("Texto", "*.txt")]
    )

    if not caminho:
        return

    arquivo_atual = caminho

    try:
        with open(caminho, "r", encoding="utf-8") as f:
            conteudo = f.read()

        editor.delete("1.0", tk.END)
        editor.insert(tk.END, conteudo)

        status.config(text=f"Aberto: {caminho}")
        adicionar_log("📂 Arquivo aberto")

    except Exception as erro:
        adicionar_log(f"❌ Erro: {erro}")


def salvar_arquivo():
    global arquivo_atual

    if not arquivo_atual:

        caminho = filedialog.asksaveasfilename(
            defaultextension=".py",
            filetypes=[("Python", "*.py"), ("Texto", "*.txt")]
        )

        if not caminho:
            return

        arquivo_atual = caminho

    try:
        with open(arquivo_atual, "w", encoding="utf-8") as f:
            f.write(editor.get("1.0", tk.END))

        status.config(text=f"Salvo: {arquivo_atual}")
        adicionar_log("💾 Arquivo salvo")

    except Exception as erro:
        adicionar_log(f"❌ Erro: {erro}")
        
def verificar_codigo():

    codigo = editor.get("1.0", tk.END)

    adicionar_log("🔍 Verificando código...")

    try:

        ast.parse(codigo)

        adicionar_log("✅ Nenhum erro de sintaxe encontrado")

    except SyntaxError as erro:

        adicionar_log(
            f"❌ Linha {erro.lineno}: {erro.msg}"
        )

    except Exception as erro:

        adicionar_log(
            f"❌ Erro: {erro}"
        )

# =========================
# TOPO
# =========================

topbar = tk.Frame(root, bg="#111111", height=40)
topbar.pack(fill="x")

tk.Button(
    topbar,
    text="Novo",
    command=novo_arquivo,
    bg="#222",
    fg="white",
    relief="flat"
).pack(side="left", padx=5, pady=5)

tk.Button(
    topbar,
    text="Abrir",
    command=abrir_arquivo,
    bg="#222",
    fg="white",
    relief="flat"
).pack(side="left", padx=5)

tk.Button(
    topbar,
    text="Salvar",
    command=salvar_arquivo,
    bg="#222",
    fg="white",
    relief="flat"
).pack(side="left", padx=5)

# =========================
# DIVISÃO PRINCIPAL
# =========================

divisao = tk.PanedWindow(
    root,
    orient=tk.HORIZONTAL,
    sashwidth=5,
    bg="#1e1e1e"
)

divisao.pack(fill="both", expand=True)

# =========================
# EDITOR
# =========================

frame_editor = tk.Frame(divisao)

editor = tk.Text(
    frame_editor,
    bg="#1e1e1e",
    fg="#00ff88",
    insertbackground="white",
    font=("Consolas", 11),
    undo=True
)

editor.pack(fill="both", expand=True)

# =========================
# HORIZON AI
# =========================

frame_painel = tk.Frame(
    divisao,
    bg="#111111",
    width=250
)

frame_painel.pack_propagate(False)

titulo = tk.Label(
    frame_painel,
    text="Horizon AI",
    bg="#111111",
    fg="#00ff88",
    font=("Arial", 10, "bold")
)

titulo.pack(fill="x", pady=5)

painel = tk.Text(
    frame_painel,
    bg="#111111",
    fg="white",
    font=("Consolas", 10)
)

painel.pack(fill="both", expand=True)

painel.insert(
    tk.END,
    "=== Horizon AI ===\n\n"
    "Editor iniciado.\n"
)

painel.config(state="disabled")

# Adiciona os painéis

divisao.add(frame_editor, stretch="always")
divisao.add(frame_painel)

# =========================
# STATUS BAR
# =========================

status = tk.Label(
    root,
    text="Horizon Editor iniciado",
    anchor="w",
    bg="#111111",
    fg="white"
)

status.pack(fill="x")

# =========================
# START
# =========================

root.mainloop()