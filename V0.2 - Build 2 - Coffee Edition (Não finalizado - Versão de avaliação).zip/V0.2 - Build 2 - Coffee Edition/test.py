from UI.bios.bios_1 import bios_sequence

bios_sequence()